import os


def where() -> str:
    # This package is imported from a zip; the readable copy of the CA bundle is the one the
    # app points SSL_CERT_FILE at (iosApp/iosApp/cacert.pem).
    env = os.environ.get("SSL_CERT_FILE")
    if env and os.path.isfile(env):
        return env
    return os.path.join(os.path.dirname(__file__), "cacert.pem")


def contents() -> str:
    with open(where(), encoding="ascii") as f:
        return f.read()
